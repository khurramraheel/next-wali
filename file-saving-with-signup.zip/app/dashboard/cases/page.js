export default()=>{

    return <div>
        <h1>yeh cases page h</h1>
    </div>

}