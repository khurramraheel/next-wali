// import Nav from "@/components/nav/nav"

export default()=>{

    return <div>


        <h1>yeh saada wala page page h</h1>
    </div>

}