import Nav from "@/components/nav/nav"

export default({children})=>{

    return <div>

            <Nav></Nav>
        
            {children}
    </div>

}