

export default()=>{

    return <div>

<input ref={nameRef} /> <br />
<input ref={passwordRef} /> <br />
<button>Signup karo</button>

    </div>

}