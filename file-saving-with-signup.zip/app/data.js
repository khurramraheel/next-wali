export let users = [
  {
    email:"a@a.com",
    password:"123"
  }
];


export let ads = [
    {
      name:"HP 650 G1",
      price:100,
      src:"https://images.olx.com.pk/thumbnails/492705938-240x180.webp"
    },
    {
      name:"DELL 5460",
      price:200,
      src:"https://images.olx.com.pk/thumbnails/493055944-240x180.webp"
    },
    {
      name:"DELL Desktop",
      price:300,
      src:"https://images.olx.com.pk/thumbnails/388020951-240x180.webp"
    },
    {
      name:"OPPO A8",
      price:400,
      src:"https://images.olx.com.pk/thumbnails/463631645-800x600.webp"
    },
    {
      name:"OPPO BRAND NEW",
      price:400,
      src:"https://images.olx.com.pk/thumbnails/463631645-800x600.webp"
    },
    {
      name:"HP 560 NEW",
      price:500,
      src:"https://images.olx.com.pk/thumbnails/463631645-800x600.webp"
    }
  ]