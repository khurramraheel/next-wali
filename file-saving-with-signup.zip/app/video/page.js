"use client";
import ReactPlayer from 'react-player'
import YouTube from 'react-youtube';

export default()=>{


    return <div>
        <YouTube videoId="t0Q2otsqC4I"></YouTube>

        <ReactPlayer controls="true" url="some.mp4"></ReactPlayer>

    </div>

}